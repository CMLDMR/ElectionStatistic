
#include "mainwindow.h"

#include <QApplication>

#include <mongocxx/instance.hpp>
#include <mongocxx/client.hpp>
#include <mongocxx/uri.hpp>
#include <bsoncxx/builder/basic/document.hpp>
#include <bsoncxx/builder/basic/kvp.hpp>
#include <bsoncxx/types.hpp>
#include <bsoncxx/json.hpp>

#include <QVariant>
#include <QStringList>

#include "xlsx/xlsxdocument.h"

#include  "../../../url.h"


#include <QDebug>
#include <QThread>


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    mongocxx::instance instance{};

    auto client = mongocxx::client(mongocxx::uri(_url));

    auto db = client.database("SECIM2023");


    QXlsx::Document doc("sandikMahalle.xlsx");
    doc.selectSheet("Sayfa1");

    QStringList mahList;
    QVector<bsoncxx::document::view> itemList;

    auto cursor = db.collection("SandikCollection").find(bsoncxx::builder::basic::document{}.view());

    for( const auto &item : cursor ){
        mahList.append(item["mahalle"].get_string().value.data());
        itemList.append(std::move(item));
    }

    mahList.removeDuplicates();




    int index = 1;


    for( const auto &mahalle : mahList ){

        int rte = 0;
        int mi = 0;
        int kk = 0;
        int so = 0;

        auto cursor1 = db.collection("SandikCollection").find(bsoncxx::builder::basic::document{}.view());

        for( const auto &sandik : cursor1 ){
            if( QString(sandik["mahalle"].get_string().value.data()) == mahalle ){
                rte += sandik["rte"].get_int32().value;
                mi += sandik["mi"].get_int32().value;
                kk += sandik["kk"].get_int32().value;
                so += sandik["so"].get_int32().value;
            }
        }

        qDebug() << mahalle << rte << mi << kk << so;
        doc.write(index,1,mahalle);
        doc.write(index,2,rte);
        doc.write(index,3,mi);
        doc.write(index,4,kk);
        doc.write(index,5,so);
        doc.write(index++,6,rte+mi+kk+so);

        QThread::currentThread()->wait(500);


    }
    doc.save();




//    for( int i = 1 ; i < 310 ; i++ ){

//        auto mahalle = doc.read(QString("B%1").arg(i)).toString();
//        auto alan = doc.read(QString("A%1").arg(i)).toString();
//        auto no = doc.read(QString("C%1").arg(i)).toInt();
//        auto telefon = doc.read(QString("D%1").arg(i)).toString();

//        auto doc = bsoncxx::builder::basic::document{};


//        doc.append(bsoncxx::builder::basic::kvp("rte",bsoncxx::types::b_int32{0}),
//                   bsoncxx::builder::basic::kvp("mi",bsoncxx::types::b_int32{0}),
//                   bsoncxx::builder::basic::kvp("kk",bsoncxx::types::b_int32{0}),
//                   bsoncxx::builder::basic::kvp("so",bsoncxx::types::b_int32{0}),
//                   bsoncxx::builder::basic::kvp("mahalle",mahalle.toStdString()),
//                   bsoncxx::builder::basic::kvp("sandikAlanadi",alan.toStdString()),
//                   bsoncxx::builder::basic::kvp("sandikno",bsoncxx::types::b_int32{no}),
//                   bsoncxx::builder::basic::kvp("telefon",telefon.toStdString()));

//        qDebug() << bsoncxx::to_json(doc.view()).c_str();

//        try {
//            db.collection("SandikCollection").insert_one(doc.view());

//        } catch (...) {

//        }

//    }





    return a.exec();
}
